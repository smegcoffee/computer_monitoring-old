<!DOCTYPE html>
<html>
<head>
    <title>Notification</title>
</head>
<body>
    <p>{{ $content }}</p>
</body>
</html>
