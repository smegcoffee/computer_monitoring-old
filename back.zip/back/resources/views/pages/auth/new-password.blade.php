<div class="card">
    <div class="card-body">
        <p>Hello, {{ $firstName }} {{ $lastName }},</p>

        <p>Your new password is: <strong>{{ $newPassword }}</strong></p>

        <p>Please login using this new password and update it as soon as possible.</p>

        <p>Thank you,</p>
        <p>Regards, SMCT Computer Monitoring</p>
    </div>
</div>