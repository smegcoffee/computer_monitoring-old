<div class="card">
    <div class="card-body">
        <p>Hello, <?php echo e($firstName); ?> <?php echo e($lastName); ?>,</p>

        <p>Your new password is: <strong><?php echo e($newPassword); ?></strong></p>

        <p>Please login using this new password and update it as soon as possible.</p>

        <p>Thank you,</p>
        <p>Regards, SMCT Computer Monitoring</p>
    </div>
</div><?php /**PATH C:\Users\Allan\Web\computer_monitoring\back\resources\views/pages/auth/new-password.blade.php ENDPATH**/ ?>