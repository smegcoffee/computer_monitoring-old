<!DOCTYPE html>
<html>
<head>
    <title>Notification</title>
</head>
<body>
    <p><?php echo e($content); ?></p>
</body>
</html>
<?php /**PATH C:\Users\Allan\Web\computer_monitoring\back\resources\views/emails/send-email.blade.php ENDPATH**/ ?>